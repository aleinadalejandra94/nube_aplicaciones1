<!DOCTYPE html>
  <html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=0.0">

    <?php
    include("php/links.html");
    ?>
    </head>

    <body>
    <?php
    include("php/menu.php");
    ?>
<h1>Esta es la pagina de Bombillo</h1>
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.min.js"></script>
    </body>
  </html>