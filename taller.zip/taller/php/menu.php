<?php
include("php/links.html");
?>

<nav class="yellow">
    <div class="nav-wrapper">
      <a href="#!" class="brand-logo right"><i class="material-icons"></i>Narvaez</a>
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul class="left hide-on-med-and-down">
        <li><a href="ambulancia.php"><i class="icon-bombillo"></i></a></li>
        <li><a href="manzana.php"><i class="icon-candado"></i></a></li>
        <li><a href="cucaracha.php"><i class="icon-microfono"></i></a></li>
      </ul>
      <ul class="side-nav" id="mobile-demo">
        <li><a href="ambulancia.php">Bombillo</a></li>
        <li><a href="manzana.php">Candado</a></li>
        <li><a href="cucaracha.php">Microfono</a></li>
       
      </ul>
    </div>
  </nav>
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.min.js"></script>
      <script> $( document ).ready(function(){ $(".button-collapse").sideNav();})</script>
